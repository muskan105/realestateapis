from django.contrib import admin
from .models import Ghar
# Register your models here.
admin.site.register(Ghar)